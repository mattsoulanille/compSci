/**
  * CashRegister.java program
  * @author Matthew Soulanille
  * @version 2014-09-26
*/

public void CashRegister
{
    public static final double dol = 1.0;
    public static final double qua = 0.25;
    public static final double dim = 0.1;
    public static final double n = 0.05;
    public static final double p = .01;
}
